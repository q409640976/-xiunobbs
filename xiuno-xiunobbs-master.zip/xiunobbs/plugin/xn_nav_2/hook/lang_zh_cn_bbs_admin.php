	'nav_2_on'=>'是否开启二级导航',
	'nav_2_bbs_on'=>'是否在导航显示"论坛"链接',
	'nav_2_forum_list_pc_on'=>'是否在二级导航下显示版块列表（PC）',
	'nav_2_forum_list_mobile_on'=>'是否在二级导航下显示版块列表（手机）',