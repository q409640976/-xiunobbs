<?php

/*
	Xiuno BBS 4.0 消息
*/

!defined('DEBUG') AND exit('Forbidden');


?>