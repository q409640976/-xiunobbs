
APP_PATH.'plugin/xn_tag/model/tag_cate.func.php',
APP_PATH.'plugin/xn_tag/model/tag.func.php',
APP_PATH.'plugin/xn_tag/model/tag_thread.func.php',