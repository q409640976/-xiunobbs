/*
include APP_PATH.'plugin/xn_mobile/model/sms.func.php';
$r = sms_send_code('15600900902', '222333');
print_r($r);
exit;
*/